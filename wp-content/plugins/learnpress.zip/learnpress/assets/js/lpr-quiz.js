/**
 * Created by foobla on 3/26/2015.
 */


jQuery(document).ready(function($){
    var dataFromParent;
    function init() {
        console.log(dataFromParent);
    }
});

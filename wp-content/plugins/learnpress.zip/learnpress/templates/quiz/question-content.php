
<?php do_action( 'learn_press_before_quiz_question_nav_content' );?>

<div class="quiz-question-content">
    <?php do_action( 'learn_press_quiz_question_description' );?>
</div>

<?php do_action( 'learn_press_after_quiz_question_nav_content' );?>

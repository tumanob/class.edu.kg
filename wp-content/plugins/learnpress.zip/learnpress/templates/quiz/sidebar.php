<?php if( learn_press_get_quiz_questions() ):?>
<div class="quiz-sidebar">
    <?php do_action( 'learn_press_content_quiz_sidebar' );?>
</div>
<?php endif;?>
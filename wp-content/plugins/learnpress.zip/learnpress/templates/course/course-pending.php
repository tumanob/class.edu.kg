<div class="course-status">
<?php
    printf( __( 'You have taken this course but it\'s status is %s', 'learn_press' ), learn_press_get_user_course_status() );
?>
</div>
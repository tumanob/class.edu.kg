<h3>
    <?php do_action( 'learn_press_begin_course_content_lesson_title');?>
    <?php the_title();?>
    <?php do_action( 'learn_press_end_course_content_lesson_title');?>
</h3>
<div class="course-description">
    <?php do_action( 'learn_press_begin_course_content_course_description' );?>
    <?php the_content(); ?>
    <?php do_action( 'learn_press_end_course_content_course_description' );?>
</div>